import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { Package } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/feedback/EmptyState";
import { getMyOrders } from "@/lib/order.functions";
import { toMoney } from "@/lib/mappers";
import { formatMoney } from "@/lib/format";

export const Route = createFileRoute("/account/orders")({
  head: () => ({
    meta: [{ title: "Mes commandes — BA Medical Store" }, { name: "robots", content: "noindex" }],
  }),
  component: AccountOrdersPage,
});

const STATUS_LABELS: Record<string, string> = {
  pending_payment: "En attente de paiement",
  paid: "Payée",
  processing: "En préparation",
  shipped: "Expédiée",
  delivered: "Livrée",
  cancelled: "Annulée",
  refunded: "Remboursée",
};

function AccountOrdersPage() {
  const fetchOrders = useServerFn(getMyOrders);
  const { data, isPending, isError, error } = useQuery({
    queryKey: ["orders", "me"],
    queryFn: () => fetchOrders(),
  });

  if (isPending) {
    return <div className="space-y-4 text-muted-foreground">Chargement de vos commandes…</div>;
  }

  if (isError) {
    return (
      <Card className="p-6 text-sm text-destructive">
        {error instanceof Error ? error.message : "Impossible de charger vos commandes."}
      </Card>
    );
  }

  const orders = data?.orders ?? [];

  if (orders.length === 0) {
    return (
      <EmptyState
        icon={Package}
        title="Aucune commande pour le moment"
        description="Vos commandes passées apparaîtront ici."
        action={
          <Button asChild>
            <Link to="/catalogue">Découvrir le catalogue</Link>
          </Button>
        }
      />
    );
  }

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold">Mes commandes</h1>
      {orders.map((order) => (
        <Card key={order.id} className="flex items-center justify-between p-4">
          <div className="space-y-1">
            <p className="font-semibold">{order.order_number}</p>
            <p className="text-sm text-muted-foreground">
              {new Date(order.created_at).toLocaleDateString("fr-TN", {
                day: "2-digit",
                month: "long",
                year: "numeric",
              })}
            </p>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="outline">{STATUS_LABELS[order.status] ?? order.status}</Badge>
            <span className="font-semibold">
              {formatMoney(toMoney(order.total, order.currency))}
            </span>
          </div>
        </Card>
      ))}
    </div>
  );
}
