# INTEGRATION — JOB S4

## Corrections apportées vs le package précédent
1. **`orders.delete()` supprimé** — 0 occurrence (impossible avec les GRANT/RLS réels : `authenticated` n'a pas de GRANT DELETE, et `orders_staff_update` est réservée `is_staff()`). Remplacé par un throw direct + documentation du scénario de commande fantôme.
2. **`coupon_code` propagé** — lu depuis `carts.applied_coupon_code` (même RLS que `readCart`, pas de logique de validation réimplémentée côté TS) et transmis à l'INSERT `orders`. La remise reste calculée exclusivement par `recompute_order_totals` (DB).
3. **Gaps documentés dans le code** (`order.server.ts`, docstrings) : shipping non verrouillé au niveau REST, quantité non bornée en DB, absence d'idempotence DB, Retail Activation Gate (`catalog_activation_status`) non vérifié par les policies RLS existantes.
4. `address_line2` : inchangé, déjà correct.

## Application
1. Copier les 4 fichiers de `files/` aux mêmes chemins dans le repo (ou `git apply DIFF.md` depuis la racine).
2. `npm run dev`/`build` une fois pour régénérer `routeTree.gen.ts` automatiquement.
3. Vérifier les SHA-256 (`MANIFEST.md`) après copie.
4. Test manuel réel obligatoire avant toute mise en prod (non exécutable depuis ce sandbox).

## Décisions PO en attente (non résolues ici, volontairement)
- RPC transactionnelle `create_order` (ferme le gap "commande fantôme")
- Verrouillage DB de `shipping_cost` (contrainte ou trigger)
- Contrainte DB sur `order_items.quantity` (ex. 1–99)
- Idempotency key / contrainte anti-double-soumission DB
- Mise à jour des policies RLS produits pour vérifier `catalog_activation_status`
