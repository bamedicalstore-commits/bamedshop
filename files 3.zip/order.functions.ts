import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  normalizeAddressInput,
  normalizePaymentMethod,
  placeOrder,
  type AddressInput,
  type PaymentMethod,
} from "./order.server";

/**
 * Crée une commande réelle à partir du panier serveur de l'utilisateur
 * authentifié. Voir order.server.ts::placeOrder pour la séquence complète
 * (lecture panier → validation → adresse → commande → lignes → vidage panier).
 */
export const placeMyOrder = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: { address: AddressInput; paymentMethod: PaymentMethod }) => ({
    address: normalizeAddressInput(input?.address),
    paymentMethod: normalizePaymentMethod(input?.paymentMethod),
  }))
  .handler(async ({ data, context }) =>
    placeOrder(context.supabase, context.userId, data.address, data.paymentMethod),
  );

/** Historique des commandes de l'utilisateur authentifié (RLS orders_self_read). */
export const getMyOrders = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("orders")
      .select("id, order_number, status, payment_method, total, currency, created_at")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return { orders: data ?? [] };
  });
