import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { CheckCircle2, CreditCard, MapPin, ShieldCheck } from "lucide-react";
import { SiteLayout } from "@/components/layout/SiteLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useCart, CART_QUERY_KEY } from "@/hooks/useCart";
import { useAuthSession } from "@/hooks/useAuthSession";
import { placeMyOrder } from "@/lib/order.functions";
import { CHECKOUT_SHIPPING_COST_MINOR, type PaymentMethod } from "@/lib/order.server";
import { formatMoney } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Commande — BA Medical Store" },
      { name: "description", content: "Finalisez votre commande en toute sécurité." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: CheckoutPage,
});

const PAYMENT_OPTIONS: Array<{ value: PaymentMethod; label: string; hint: string }> = [
  {
    value: "bank_transfer",
    label: "Virement bancaire",
    hint: "Coordonnées bancaires envoyées après validation de la commande",
  },
  {
    value: "cash_on_delivery",
    label: "Paiement à la livraison",
    hint: "Réglez en espèces à la réception",
  },
  { value: "card", label: "Carte bancaire", hint: "Paiement en ligne sécurisé" },
];

const EMPTY_ADDRESS = {
  recipientName: "",
  phone: "",
  addressLine1: "",
  addressLine2: "",
  city: "",
  governorate: "",
  postalCode: "",
};

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className={cn("flex items-center justify-between text-sm", bold && "text-base font-bold")}>
      <span className={cn(!bold && "text-muted-foreground")}>{label}</span>
      <span>{value}</span>
    </div>
  );
}

function CheckoutPage() {
  const { isAuthenticated, loading: authLoading } = useAuthSession();
  const cart = useCart();
  const queryClient = useQueryClient();
  const submitOrder = useServerFn(placeMyOrder);

  const [address, setAddress] = useState(EMPTY_ADDRESS);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("bank_transfer");

  const placeOrder = useMutation({
    mutationFn: () => submitOrder({ data: { address, paymentMethod } }),
    onSuccess: () => {
      // Le panier est déjà vidé côté serveur (placeOrder) ; on invalide juste
      // le cache client pour que le badge panier reflète l'état réel.
      void queryClient.invalidateQueries({ queryKey: CART_QUERY_KEY });
    },
  });

  const field = (key: keyof typeof EMPTY_ADDRESS) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setAddress((a) => ({ ...a, [key]: e.target.value }));

  if (authLoading || cart.isLoading) {
    return (
      <SiteLayout>
        <div className="container-page py-20 text-center text-muted-foreground">Chargement…</div>
      </SiteLayout>
    );
  }

  if (!isAuthenticated) {
    return (
      <SiteLayout>
        <div className="container-page flex flex-col items-center gap-4 py-24 text-center">
          <p className="text-lg font-medium">Connecte-toi pour finaliser ta commande.</p>
          <Button asChild size="lg">
            <Link to="/auth">Se connecter</Link>
          </Button>
        </div>
      </SiteLayout>
    );
  }

  if (placeOrder.isSuccess) {
    const order = placeOrder.data;
    return (
      <SiteLayout>
        <div className="container-page mx-auto max-w-lg space-y-4 py-24 text-center">
          <CheckCircle2 className="mx-auto h-14 w-14 text-primary" />
          <h1 className="text-2xl font-bold">Commande confirmée</h1>
          <p className="text-muted-foreground">
            Numéro de commande <strong className="text-foreground">{order.orderNumber}</strong>
          </p>
          <p className="text-lg font-semibold">
            {formatMoney({ amount: Math.round(order.total * 1000), currency: "TND" })}
          </p>
          <div className="flex justify-center gap-3 pt-2">
            <Button asChild>
              <Link to="/account/orders">Voir mes commandes</Link>
            </Button>
            <Button asChild variant="outline">
              <Link to="/catalogue">Continuer mes achats</Link>
            </Button>
          </div>
        </div>
      </SiteLayout>
    );
  }

  if (cart.lines.length === 0) {
    return (
      <SiteLayout>
        <div className="container-page flex flex-col items-center gap-4 py-24 text-center">
          <p className="text-lg font-medium">Ton panier est vide.</p>
          <Button asChild size="lg">
            <Link to="/catalogue">Voir le catalogue</Link>
          </Button>
        </div>
      </SiteLayout>
    );
  }

  const shippingCost = { amount: CHECKOUT_SHIPPING_COST_MINOR, currency: "TND" as const };
  const total = cart.subtotal + shippingCost.amount;
  const canSubmit =
    address.recipientName.trim() !== "" &&
    address.phone.trim() !== "" &&
    address.addressLine1.trim() !== "" &&
    address.city.trim() !== "" &&
    address.governorate.trim() !== "" &&
    !placeOrder.isPending;

  return (
    <SiteLayout>
      <form
        className="container-page grid gap-8 py-10 lg:grid-cols-[1fr_360px]"
        onSubmit={(e) => {
          e.preventDefault();
          if (canSubmit) placeOrder.mutate();
        }}
      >
        <div className="space-y-6">
          <Card className="space-y-4 p-6">
            <div className="flex items-center gap-2 font-semibold">
              <MapPin className="h-4 w-4" /> Adresse de livraison
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="recipientName">Nom du destinataire</Label>
                <Input
                  id="recipientName"
                  value={address.recipientName}
                  onChange={field("recipientName")}
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="phone">Téléphone</Label>
                <Input id="phone" value={address.phone} onChange={field("phone")} required />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="addressLine1">Adresse</Label>
              <Input
                id="addressLine1"
                value={address.addressLine1}
                onChange={field("addressLine1")}
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="addressLine2">Complément (optionnel)</Label>
              <Input
                id="addressLine2"
                value={address.addressLine2}
                onChange={field("addressLine2")}
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-1.5">
                <Label htmlFor="city">Ville</Label>
                <Input id="city" value={address.city} onChange={field("city")} required />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="governorate">Gouvernorat</Label>
                <Input
                  id="governorate"
                  value={address.governorate}
                  onChange={field("governorate")}
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="postalCode">Code postal</Label>
                <Input id="postalCode" value={address.postalCode} onChange={field("postalCode")} />
              </div>
            </div>
          </Card>

          <Card className="space-y-4 p-6">
            <div className="flex items-center gap-2 font-semibold">
              <CreditCard className="h-4 w-4" /> Mode de paiement
            </div>
            <RadioGroup
              value={paymentMethod}
              onValueChange={(v) => setPaymentMethod(v as PaymentMethod)}
            >
              {PAYMENT_OPTIONS.map((opt) => (
                <label
                  key={opt.value}
                  className="flex cursor-pointer items-start gap-3 rounded-lg border p-3 has-[[data-state=checked]]:border-primary"
                >
                  <RadioGroupItem value={opt.value} className="mt-1" />
                  <div>
                    <p className="font-medium">{opt.label}</p>
                    <p className="text-sm text-muted-foreground">{opt.hint}</p>
                  </div>
                </label>
              ))}
            </RadioGroup>
          </Card>

          {placeOrder.isError && (
            <Alert variant="destructive">
              <AlertDescription>
                {placeOrder.error instanceof Error
                  ? placeOrder.error.message
                  : "Une erreur est survenue, réessaie."}
              </AlertDescription>
            </Alert>
          )}
        </div>

        <Card className="h-fit space-y-4 p-6">
          <h2 className="font-semibold">Récapitulatif</h2>
          <div className="space-y-2">
            {cart.lines.map((line) => (
              <div key={line.id} className="flex justify-between text-sm">
                <span className="text-muted-foreground">
                  {line.product.name} × {line.quantity}
                </span>
                <span>{formatMoney(line.lineTotal)}</span>
              </div>
            ))}
          </div>
          <Separator />
          <Row
            label={`Articles (${cart.count})`}
            value={formatMoney({ amount: cart.subtotal, currency: "TND" })}
          />
          <Row label="Livraison" value={formatMoney(shippingCost)} />
          <Separator />
          <Row label="Total" value={formatMoney({ amount: total, currency: "TND" })} bold />
          <Button type="submit" className="w-full" size="lg" disabled={!canSubmit}>
            {placeOrder.isPending ? "Création de la commande…" : "Confirmer la commande"}
          </Button>
          <p className="flex items-center gap-1 text-xs text-muted-foreground">
            <ShieldCheck className="h-3 w-3" /> Paiement sécurisé — données chiffrées
          </p>
        </Card>
      </form>
    </SiteLayout>
  );
}
