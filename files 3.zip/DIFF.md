diff --git a/src/lib/order.functions.ts b/src/lib/order.functions.ts
new file mode 100644
index 0000000..f0acd6b
--- /dev/null
+++ b/src/lib/order.functions.ts
@@ -0,0 +1,37 @@
+import { createServerFn } from "@tanstack/react-start";
+import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
+import {
+  normalizeAddressInput,
+  normalizePaymentMethod,
+  placeOrder,
+  type AddressInput,
+  type PaymentMethod,
+} from "./order.server";
+
+/**
+ * Crée une commande réelle à partir du panier serveur de l'utilisateur
+ * authentifié. Voir order.server.ts::placeOrder pour la séquence complète
+ * (lecture panier → validation → adresse → commande → lignes → vidage panier).
+ */
+export const placeMyOrder = createServerFn({ method: "POST" })
+  .middleware([requireSupabaseAuth])
+  .validator((input: { address: AddressInput; paymentMethod: PaymentMethod }) => ({
+    address: normalizeAddressInput(input?.address),
+    paymentMethod: normalizePaymentMethod(input?.paymentMethod),
+  }))
+  .handler(async ({ data, context }) =>
+    placeOrder(context.supabase, context.userId, data.address, data.paymentMethod),
+  );
+
+/** Historique des commandes de l'utilisateur authentifié (RLS orders_self_read). */
+export const getMyOrders = createServerFn({ method: "GET" })
+  .middleware([requireSupabaseAuth])
+  .handler(async ({ context }) => {
+    const { data, error } = await context.supabase
+      .from("orders")
+      .select("id, order_number, status, payment_method, total, currency, created_at")
+      .eq("user_id", context.userId)
+      .order("created_at", { ascending: false });
+    if (error) throw new Error(error.message);
+    return { orders: data ?? [] };
+  });
diff --git a/src/lib/order.server.ts b/src/lib/order.server.ts
new file mode 100644
index 0000000..ac057cf
--- /dev/null
+++ b/src/lib/order.server.ts
@@ -0,0 +1,277 @@
+/**
+ * Helpers serveur de création de commande.
+ * Utilise EXCLUSIVEMENT le client Supabase authentifié (RLS as user).
+ * Aucun client service-role ici — même contrainte que cart.server.ts.
+ *
+ * Autorité des prix/totaux : les triggers DB existants (enforce_order_item_price,
+ * enforce_order_totals, recompute_order_totals, resolve_product_price) recalculent
+ * unit_price/line_total/subtotal/total à l'insertion. Ce fichier ne fait JAMAIS
+ * confiance à un prix qu'il aurait lui-même calculé — il lit toujours la valeur
+ * finale en DB après coup (voir `placeOrder`, étape 6).
+ */
+import type { AuthedClient } from "./cart.server";
+import { readCart } from "./cart.server";
+
+export const PAYMENT_METHODS = ["card", "bank_transfer", "cash_on_delivery"] as const;
+export type PaymentMethod = (typeof PAYMENT_METHODS)[number];
+
+/**
+ * Frais de port MVP — PROVISOIRE, non validé comme politique commerciale.
+ * Unité mineure (millimes), cohérent avec `toMoney()`/`Money.amount` utilisé
+ * partout ailleurs dans l'app. 8000 = 8.000 DT. Source UNIQUE : ne jamais
+ * dupliquer cette valeur ailleurs. À remplacer avant tout lancement réel par
+ * une vraie politique de frais de port (fixe, par gouvernorat, par poids...).
+ *
+ * GAP CONNU (autorité) : cette constante n'est appliquée que par ce chemin
+ * applicatif (Server Function). `shipping_cost` n'est PAS verrouillé côté
+ * DB — un appel REST/PostgREST direct authentifié pourrait insérer une
+ * valeur arbitraire dans `orders.shipping_cost` (aucun trigger ne la
+ * contraint, contrairement à `subtotal`/`total`/`unit_price`). Protégé
+ * uniquement pour le parcours officiel de l'application. Remédiation DB
+ * (contrainte CHECK ou verrouillage trigger) : décision PO, hors périmètre
+ * de ce fichier.
+ */
+export const CHECKOUT_SHIPPING_COST_MINOR = 8000;
+
+export type AddressInput = {
+  recipientName: string;
+  phone: string;
+  addressLine1: string;
+  addressLine2?: string;
+  city: string;
+  governorate: string;
+  postalCode?: string;
+};
+
+export function normalizeAddressInput(input: unknown): AddressInput {
+  const v = (input ?? {}) as Record<string, unknown>;
+  const str = (x: unknown) => String(x ?? "").trim();
+
+  const recipientName = str(v.recipientName);
+  const phone = str(v.phone);
+  const addressLine1 = str(v.addressLine1);
+  const city = str(v.city);
+  const governorate = str(v.governorate);
+
+  if (!recipientName) throw new Error("Nom du destinataire requis");
+  if (!phone) throw new Error("Téléphone requis");
+  if (!addressLine1) throw new Error("Adresse requise");
+  if (!city) throw new Error("Ville requise");
+  if (!governorate) throw new Error("Gouvernorat requis");
+
+  return {
+    recipientName,
+    phone,
+    addressLine1,
+    addressLine2: v.addressLine2 ? str(v.addressLine2) : undefined,
+    city,
+    governorate,
+    postalCode: v.postalCode ? str(v.postalCode) : undefined,
+  };
+}
+
+export function normalizePaymentMethod(input: unknown): PaymentMethod {
+  const v = String(input ?? "");
+  if (!(PAYMENT_METHODS as readonly string[]).includes(v)) {
+    throw new Error("Mode de paiement invalide");
+  }
+  return v as PaymentMethod;
+}
+
+/**
+ * BAMS-{année}-{6 chiffres}. Pas de séquence DB (aucune n'existe) — unicité
+ * gérée par retry sur violation de contrainte UNIQUE (voir placeOrder).
+ */
+function generateOrderNumber(): string {
+  const year = new Date().getFullYear();
+  const rand = Math.floor(100000 + Math.random() * 900000);
+  return `BAMS-${year}-${rand}`;
+}
+
+export type PlaceOrderResult = {
+  orderId: string;
+  orderNumber: string;
+  status: string;
+  subtotal: number;
+  shippingCost: number;
+  total: number;
+};
+
+/**
+ * REAL CART → SERVER VALIDATION → CREATE ADDRESS → CREATE ORDER →
+ * CREATE ORDER_ITEMS SNAPSHOTS → CLEAR CART → RETURN REAL ORDER.
+ *
+ * Atomicité : PAS de transaction DB multi-étapes (aucune RPC n'existe pour
+ * ça — en créer une sortirait du scope de cette tâche, voir le rapport).
+ * Ce qui EST garanti :
+ *   - l'insert de tous les order_items est UNE seule instruction SQL
+ *     multi-lignes → atomique au niveau Postgres (tout ou rien) ;
+ *   - subtotal/total ne sont JAMAIS calculés ici : toujours relus depuis la
+ *     DB après le trigger `recompute_order_totals`.
+ *
+ * GAP CONNU (commande fantôme) : si l'insert order_items échoue APRÈS que
+ * `orders` a été créée, AUCUNE compensation n'est possible — `authenticated`
+ * n'a ni GRANT DELETE ni policy UPDATE non-staff sur `orders` (vérifié :
+ * seule `orders_staff_update` existe, réservée à `is_staff()`). Une
+ * tentative de DELETE échouerait silencieusement, c'est pourquoi elle n'est
+ * plus tentée ici (voir plus bas). Une commande à 0 ligne peut donc rester
+ * en base dans ce cas rare — `status=pending_payment`, aucun `order_items`.
+ * Remédiation cible : RPC transactionnelle `create_order`. Décision PO
+ * requise, non implémentée ici.
+ *
+ * GAP CONNU (quantité) : la commande hérite de la quantité déjà validée par
+ * le panier (`cart_items`). La DB n'impose actuellement aucune borne
+ * (ex. 1–99) au niveau `order_items.quantity` — seule une valeur positive
+ * est vérifiée par le trigger. Pas de correction ici (toucherait
+ * cart.server.ts/schema, hors périmètre de ce fichier).
+ *
+ * GAP CONNU (idempotence) : le double-clic est bloqué côté UI
+ * (`checkout.tsx`, bouton désactivé pendant la mutation). Deux onglets ou
+ * deux requêtes réseau parallèles peuvent en revanche produire deux
+ * commandes distinctes — aucune protection DB (idempotency key) n'existe.
+ * Décision PO requise pour une vraie garantie.
+ */
+export async function placeOrder(
+  supabase: AuthedClient,
+  userId: string,
+  address: AddressInput,
+  paymentMethod: PaymentMethod,
+): Promise<PlaceOrderResult> {
+  const cart = await readCart(supabase, userId);
+  if (cart.lines.length === 0) {
+    throw new Error("Le panier est vide");
+  }
+
+  const unavailable = cart.lines.find((l) => !l.product.active);
+  if (unavailable) {
+    throw new Error(`"${unavailable.product.name}" n'est plus disponible à la vente`);
+  }
+  // GAP CONNU (Retail Activation Gate) : cette vérification ne couvre que
+  // `products.active`. La colonne `catalog_activation_status` (DRAFT /
+  // BLOCKED / ACTIVE) existe en DB mais n'est vérifiée ni ici, ni par les
+  // policies RLS `products_public_read_active`/`products_auth_read`
+  // (toutes deux `USING (active)` uniquement — vérifié dans les
+  // migrations). Un produit `active=true` mais pas encore
+  // `catalog_activation_status='ACTIVE'` resterait commandable. Correction
+  // hors périmètre de ce fichier (toucherait catalog.functions.ts /
+  // cart.server.ts / RLS) — décision PO requise.
+
+  // Coupon éventuellement appliqué au panier. Lecture directe (pas via
+  // cart.server.ts, hors périmètre) — même RLS `carts_self` que readCart().
+  // Aucune revalidation ici : la remise reste calculée par la DB
+  // (`recompute_order_totals`), on ne fait que transmettre le code.
+  let couponCode: string | null = null;
+  if (cart.cartId) {
+    const { data: cartRow } = await supabase
+      .from("carts")
+      .select("applied_coupon_code")
+      .eq("id", cart.cartId)
+      .maybeSingle();
+    couponCode = cartRow?.applied_coupon_code ?? null;
+  }
+
+  const { data: addressRow, error: addressError } = await supabase
+    .from("addresses")
+    .insert({
+      user_id: userId,
+      recipient_name: address.recipientName,
+      phone: address.phone,
+      address_line1: address.addressLine1,
+      address_line2: address.addressLine2 ?? null,
+      city: address.city,
+      governorate: address.governorate,
+      postal_code: address.postalCode ?? null,
+      is_default: false,
+    })
+    .select("id")
+    .single();
+  if (addressError || !addressRow) {
+    throw new Error(addressError?.message ?? "Échec de création de l'adresse");
+  }
+
+  const shippingCostTnd = CHECKOUT_SHIPPING_COST_MINOR / 1000;
+  let orderId: string | null = null;
+
+  for (let attempt = 0; attempt < 3 && !orderId; attempt++) {
+    const { data: orderRow, error: orderError } = await supabase
+      .from("orders")
+      .insert({
+        order_number: generateOrderNumber(),
+        user_id: userId,
+        shipping_address_id: addressRow.id,
+        payment_method: paymentMethod,
+        shipping_cost: shippingCostTnd,
+        coupon_code: couponCode,
+        // Valeurs bouchon : le trigger `enforce_order_totals` impose 0 pour
+        // un non-staff de toute façon ; `recompute_order_totals` les
+        // remplacera par les vraies valeurs (et appliquera la remise du
+        // coupon éventuel) après l'insert des lignes.
+        subtotal: 0,
+        discount_total: 0,
+        total: 0,
+      })
+      .select("id")
+      .single();
+
+    if (!orderError && orderRow) {
+      orderId = orderRow.id;
+      break;
+    }
+    // 23505 = unique_violation → collision order_number, on réessaie.
+    if (orderError && orderError.code !== "23505") {
+      throw new Error(orderError.message);
+    }
+  }
+  if (!orderId) {
+    throw new Error("Impossible de générer un numéro de commande unique — réessaie");
+  }
+
+  const { error: itemsError } = await supabase.from("order_items").insert(
+    cart.lines.map((line) => ({
+      order_id: orderId as string,
+      product_id: line.productId,
+      product_name: line.product.name,
+      quantity: line.quantity,
+      // Ignorés par le trigger enforce_order_item_price (autorité DB réelle).
+      unit_price: 0,
+      line_total: 0,
+    })),
+  );
+
+  if (itemsError) {
+    // Pas de compensation possible ici : `authenticated` n'a ni GRANT DELETE
+    // ni policy UPDATE sur `orders` (orders_staff_update est réservée au
+    // staff — vérifié dans la migration). Une tentative de DELETE échouerait
+    // silencieusement. On assume donc, honnêtement, qu'une commande à 0
+    // ligne peut rester en base dans ce cas rare (statut pending_payment,
+    // total = shipping_cost). Nettoyage : admin uniquement, ou une future
+    // policy dédiée — décision PO, pas une correction silencieuse ici.
+    throw new Error(itemsError.message);
+  }
+
+  const { data: finalOrder, error: finalError } = await supabase
+    .from("orders")
+    .select("id, order_number, status, subtotal, shipping_cost, total")
+    .eq("id", orderId)
+    .single();
+  if (finalError || !finalOrder) {
+    throw new Error(finalError?.message ?? "Commande créée mais impossible à relire");
+  }
+
+  if (cart.cartId) {
+    const { error: clearError } = await supabase
+      .from("cart_items")
+      .delete()
+      .eq("cart_id", cart.cartId);
+    if (clearError) throw new Error(clearError.message);
+  }
+
+  return {
+    orderId: finalOrder.id,
+    orderNumber: finalOrder.order_number,
+    status: finalOrder.status,
+    subtotal: Number(finalOrder.subtotal),
+    shippingCost: Number(finalOrder.shipping_cost),
+    total: Number(finalOrder.total),
+  };
+}
diff --git a/src/routes/account.orders.tsx b/src/routes/account.orders.tsx
index 8ef4484..e4774fa 100644
--- a/src/routes/account.orders.tsx
+++ b/src/routes/account.orders.tsx
@@ -1,73 +1,91 @@
-import { createFileRoute } from "@tanstack/react-router";
+import { createFileRoute, Link } from "@tanstack/react-router";
+import { useServerFn } from "@tanstack/react-start";
+import { useQuery } from "@tanstack/react-query";
+import { Package } from "lucide-react";
 import { Card } from "@/components/ui/card";
 import { Badge } from "@/components/ui/badge";
 import { Button } from "@/components/ui/button";
-import {
-  Table,
-  TableBody,
-  TableCell,
-  TableHead,
-  TableHeader,
-  TableRow,
-} from "@/components/ui/table";
 import { EmptyState } from "@/components/feedback/EmptyState";
-import { Package } from "lucide-react";
+import { getMyOrders } from "@/lib/order.functions";
+import { toMoney } from "@/lib/mappers";
+import { formatMoney } from "@/lib/format";
 
 export const Route = createFileRoute("/account/orders")({
-  component: OrdersPage,
+  head: () => ({
+    meta: [{ title: "Mes commandes — BA Medical Store" }, { name: "robots", content: "noindex" }],
+  }),
+  component: AccountOrdersPage,
 });
 
-const ORDERS = [
-  { id: "CMD-2025-00147", date: "10 mars 2025", total: "289.000 DT", status: "delivered" },
-  { id: "CMD-2025-00098", date: "22 février 2025", total: "412.000 DT", status: "shipped" },
-  { id: "CMD-2025-00042", date: "05 février 2025", total: "89.000 DT", status: "processing" },
-] as const;
+const STATUS_LABELS: Record<string, string> = {
+  pending_payment: "En attente de paiement",
+  paid: "Payée",
+  processing: "En préparation",
+  shipped: "Expédiée",
+  delivered: "Livrée",
+  cancelled: "Annulée",
+  refunded: "Remboursée",
+};
+
+function AccountOrdersPage() {
+  const fetchOrders = useServerFn(getMyOrders);
+  const { data, isPending, isError, error } = useQuery({
+    queryKey: ["orders", "me"],
+    queryFn: () => fetchOrders(),
+  });
+
+  if (isPending) {
+    return <div className="space-y-4 text-muted-foreground">Chargement de vos commandes…</div>;
+  }
+
+  if (isError) {
+    return (
+      <Card className="p-6 text-sm text-destructive">
+        {error instanceof Error ? error.message : "Impossible de charger vos commandes."}
+      </Card>
+    );
+  }
+
+  const orders = data?.orders ?? [];
 
-const STATUS_MAP = {
-  delivered: { label: "Livrée", variant: "success" },
-  shipped: { label: "Expédiée", variant: "info" },
-  processing: { label: "En traitement", variant: "warning" },
-} as const;
+  if (orders.length === 0) {
+    return (
+      <EmptyState
+        icon={Package}
+        title="Aucune commande pour le moment"
+        description="Vos commandes passées apparaîtront ici."
+        action={
+          <Button asChild>
+            <Link to="/catalogue">Découvrir le catalogue</Link>
+          </Button>
+        }
+      />
+    );
+  }
 
-function OrdersPage() {
   return (
-    <Card className="overflow-hidden p-0">
-      <div className="border-b p-6">
-        <h2 className="text-lg font-semibold">Mes commandes</h2>
-      </div>
-      <div className="overflow-x-auto">
-        <Table>
-          <TableHeader>
-            <TableRow>
-              <TableHead>Commande</TableHead>
-              <TableHead>Date</TableHead>
-              <TableHead>Total</TableHead>
-              <TableHead>Statut</TableHead>
-              <TableHead className="text-right">Action</TableHead>
-            </TableRow>
-          </TableHeader>
-          <TableBody>
-            {ORDERS.map((o) => {
-              const s = STATUS_MAP[o.status];
-              return (
-                <TableRow key={o.id}>
-                  <TableCell className="font-medium">{o.id}</TableCell>
-                  <TableCell>{o.date}</TableCell>
-                  <TableCell>{o.total}</TableCell>
-                  <TableCell>
-                    <Badge variant={s.variant}>{s.label}</Badge>
-                  </TableCell>
-                  <TableCell className="text-right">
-                    <Button variant="outline" size="sm">
-                      Détails
-                    </Button>
-                  </TableCell>
-                </TableRow>
-              );
-            })}
-          </TableBody>
-        </Table>
-      </div>
-    </Card>
+    <div className="space-y-4">
+      <h1 className="text-xl font-bold">Mes commandes</h1>
+      {orders.map((order) => (
+        <Card key={order.id} className="flex items-center justify-between p-4">
+          <div className="space-y-1">
+            <p className="font-semibold">{order.order_number}</p>
+            <p className="text-sm text-muted-foreground">
+              {new Date(order.created_at).toLocaleDateString("fr-TN", {
+                day: "2-digit",
+                month: "long",
+                year: "numeric",
+              })}
+            </p>
+          </div>
+          <div className="flex items-center gap-4">
+            <Badge variant="outline">{STATUS_LABELS[order.status] ?? order.status}</Badge>
+            <span className="font-semibold">
+              {formatMoney(toMoney(order.total, order.currency))}
+            </span>
+          </div>
+        </Card>
+      ))}
+    </div>
   );
 }
diff --git a/src/routes/checkout.tsx b/src/routes/checkout.tsx
index 716408d..1b8704f 100644
--- a/src/routes/checkout.tsx
+++ b/src/routes/checkout.tsx
@@ -1,5 +1,8 @@
 import { createFileRoute, Link } from "@tanstack/react-router";
-import { CreditCard, MapPin, ShieldCheck, Truck } from "lucide-react";
+import { useServerFn } from "@tanstack/react-start";
+import { useMutation, useQueryClient } from "@tanstack/react-query";
+import { useState } from "react";
+import { CheckCircle2, CreditCard, MapPin, ShieldCheck } from "lucide-react";
 import { SiteLayout } from "@/components/layout/SiteLayout";
 import { Button } from "@/components/ui/button";
 import { Card } from "@/components/ui/card";
@@ -7,7 +10,13 @@ import { Input } from "@/components/ui/input";
 import { Label } from "@/components/ui/label";
 import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
 import { Separator } from "@/components/ui/separator";
-import { Textarea } from "@/components/ui/textarea";
+import { Alert, AlertDescription } from "@/components/ui/alert";
+import { useCart, CART_QUERY_KEY } from "@/hooks/useCart";
+import { useAuthSession } from "@/hooks/useAuthSession";
+import { placeMyOrder } from "@/lib/order.functions";
+import { CHECKOUT_SHIPPING_COST_MINOR, type PaymentMethod } from "@/lib/order.server";
+import { formatMoney } from "@/lib/format";
+import { cn } from "@/lib/utils";
 
 export const Route = createFileRoute("/checkout")({
   head: () => ({
@@ -20,168 +29,259 @@ export const Route = createFileRoute("/checkout")({
   component: CheckoutPage,
 });
 
-function CheckoutPage() {
-  return (
-    <SiteLayout>
-      <div className="container-page py-10">
-        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Commande</h1>
-
-        <ol className="mt-6 flex items-center gap-2 text-sm">
-          <Step n={1} label="Livraison" active />
-          <span className="h-px flex-1 bg-border" />
-          <Step n={2} label="Paiement" />
-          <span className="h-px flex-1 bg-border" />
-          <Step n={3} label="Confirmation" />
-        </ol>
-
-        <form
-          onSubmit={(e) => e.preventDefault()}
-          className="mt-8 grid gap-8 lg:grid-cols-[minmax(0,1fr)_380px]"
-        >
-          <div className="space-y-6">
-            <Card className="p-6">
-              <h2 className="flex items-center gap-2 text-lg font-semibold">
-                <MapPin className="size-5 text-primary" aria-hidden="true" /> Adresse de livraison
-              </h2>
-              <div className="mt-4 grid gap-4 sm:grid-cols-2">
-                <Field id="firstName" label="Prénom" required />
-                <Field id="lastName" label="Nom" required />
-                <Field id="email" label="Email" type="email" required />
-                <Field id="phone" label="Téléphone" type="tel" required />
-                <Field id="address" label="Adresse" required className="sm:col-span-2" />
-                <Field id="city" label="Ville" required />
-                <Field id="zip" label="Code postal" required />
-              </div>
-              <div className="mt-4">
-                <Label htmlFor="notes">Instructions de livraison (optionnel)</Label>
-                <Textarea id="notes" className="mt-2" rows={3} />
-              </div>
-            </Card>
-
-            <Card className="p-6">
-              <h2 className="flex items-center gap-2 text-lg font-semibold">
-                <Truck className="size-5 text-primary" aria-hidden="true" /> Mode de livraison
-              </h2>
-              <RadioGroup defaultValue="standard" className="mt-4 space-y-3">
-                <ShippingOption id="standard" label="Standard (24-48h)" price="8.000 DT" />
-                <ShippingOption id="express" label="Express (24h)" price="15.000 DT" />
-                <ShippingOption id="pickup" label="Retrait en magasin" price="Gratuit" />
-              </RadioGroup>
-            </Card>
-
-            <Card className="p-6">
-              <h2 className="flex items-center gap-2 text-lg font-semibold">
-                <CreditCard className="size-5 text-primary" aria-hidden="true" /> Paiement
-              </h2>
-              <RadioGroup defaultValue="card" className="mt-4 space-y-3">
-                <PayOption id="card" label="Carte bancaire (Konnect / Flouci)" />
-                <PayOption id="cod" label="Paiement à la livraison" />
-                <PayOption id="wire" label="Virement bancaire" />
-              </RadioGroup>
-            </Card>
-          </div>
+const PAYMENT_OPTIONS: Array<{ value: PaymentMethod; label: string; hint: string }> = [
+  {
+    value: "bank_transfer",
+    label: "Virement bancaire",
+    hint: "Coordonnées bancaires envoyées après validation de la commande",
+  },
+  {
+    value: "cash_on_delivery",
+    label: "Paiement à la livraison",
+    hint: "Réglez en espèces à la réception",
+  },
+  { value: "card", label: "Carte bancaire", hint: "Paiement en ligne sécurisé" },
+];
 
-          <aside className="h-fit lg:sticky lg:top-24">
-            <Card className="p-6">
-              <h2 className="text-lg font-semibold">Récapitulatif</h2>
-              <dl className="mt-4 space-y-2 text-sm">
-                <Row label="Articles (2)" value="368.000 DT" />
-                <Row label="Livraison" value="8.000 DT" />
-              </dl>
-              <Separator className="my-4" />
-              <div className="flex items-baseline justify-between">
-                <span className="text-sm text-muted-foreground">Total TTC</span>
-                <span className="text-2xl font-bold tracking-tight">376.000 DT</span>
-              </div>
-              <Button type="submit" size="lg" width="full" className="mt-6">
-                Confirmer et payer
-              </Button>
-              <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
-                <ShieldCheck className="size-3.5" aria-hidden="true" />
-                Paiement 100% sécurisé
-              </p>
-              <Button asChild variant="ghost" width="full" className="mt-2">
-                <Link to="/cart">Modifier mon panier</Link>
-              </Button>
-            </Card>
-          </aside>
-        </form>
-      </div>
-    </SiteLayout>
-  );
-}
+const EMPTY_ADDRESS = {
+  recipientName: "",
+  phone: "",
+  addressLine1: "",
+  addressLine2: "",
+  city: "",
+  governorate: "",
+  postalCode: "",
+};
 
-function Step({ n, label, active }: { n: number; label: string; active?: boolean }) {
+function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
   return (
-    <div className="flex items-center gap-2">
-      <span
-        className={
-          active
-            ? "grid size-7 place-items-center rounded-full bg-primary text-xs font-bold text-primary-foreground"
-            : "grid size-7 place-items-center rounded-full border border-border text-xs font-bold text-muted-foreground"
-        }
-      >
-        {n}
-      </span>
-      <span className={active ? "font-semibold" : "text-muted-foreground"}>{label}</span>
+    <div className={cn("flex items-center justify-between text-sm", bold && "text-base font-bold")}>
+      <span className={cn(!bold && "text-muted-foreground")}>{label}</span>
+      <span>{value}</span>
     </div>
   );
 }
 
-function Field({
-  id,
-  label,
-  type = "text",
-  required,
-  className,
-}: {
-  id: string;
-  label: string;
-  type?: string;
-  required?: boolean;
-  className?: string;
-}) {
-  return (
-    <div className={className}>
-      <Label htmlFor={id}>
-        {label}
-        {required && <span className="text-destructive"> *</span>}
-      </Label>
-      <Input id={id} type={type} required={required} className="mt-2" />
-    </div>
-  );
-}
+function CheckoutPage() {
+  const { isAuthenticated, loading: authLoading } = useAuthSession();
+  const cart = useCart();
+  const queryClient = useQueryClient();
+  const submitOrder = useServerFn(placeMyOrder);
 
-function ShippingOption({ id, label, price }: { id: string; label: string; price: string }) {
-  return (
-    <Label
-      htmlFor={id}
-      className="flex cursor-pointer items-center gap-3 rounded-md border border-input p-4 hover:bg-accent has-[:checked]:border-primary has-[:checked]:bg-primary-soft"
-    >
-      <RadioGroupItem value={id} id={id} />
-      <span className="flex-1 font-medium">{label}</span>
-      <span className="text-sm font-semibold">{price}</span>
-    </Label>
-  );
-}
+  const [address, setAddress] = useState(EMPTY_ADDRESS);
+  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("bank_transfer");
 
-function PayOption({ id, label }: { id: string; label: string }) {
-  return (
-    <Label
-      htmlFor={id}
-      className="flex cursor-pointer items-center gap-3 rounded-md border border-input p-4 hover:bg-accent has-[:checked]:border-primary has-[:checked]:bg-primary-soft"
-    >
-      <RadioGroupItem value={id} id={id} />
-      <span className="font-medium">{label}</span>
-    </Label>
-  );
-}
+  const placeOrder = useMutation({
+    mutationFn: () => submitOrder({ data: { address, paymentMethod } }),
+    onSuccess: () => {
+      // Le panier est déjà vidé côté serveur (placeOrder) ; on invalide juste
+      // le cache client pour que le badge panier reflète l'état réel.
+      void queryClient.invalidateQueries({ queryKey: CART_QUERY_KEY });
+    },
+  });
+
+  const field = (key: keyof typeof EMPTY_ADDRESS) => (e: React.ChangeEvent<HTMLInputElement>) =>
+    setAddress((a) => ({ ...a, [key]: e.target.value }));
+
+  if (authLoading || cart.isLoading) {
+    return (
+      <SiteLayout>
+        <div className="container-page py-20 text-center text-muted-foreground">Chargement…</div>
+      </SiteLayout>
+    );
+  }
+
+  if (!isAuthenticated) {
+    return (
+      <SiteLayout>
+        <div className="container-page flex flex-col items-center gap-4 py-24 text-center">
+          <p className="text-lg font-medium">Connecte-toi pour finaliser ta commande.</p>
+          <Button asChild size="lg">
+            <Link to="/auth">Se connecter</Link>
+          </Button>
+        </div>
+      </SiteLayout>
+    );
+  }
+
+  if (placeOrder.isSuccess) {
+    const order = placeOrder.data;
+    return (
+      <SiteLayout>
+        <div className="container-page mx-auto max-w-lg space-y-4 py-24 text-center">
+          <CheckCircle2 className="mx-auto h-14 w-14 text-primary" />
+          <h1 className="text-2xl font-bold">Commande confirmée</h1>
+          <p className="text-muted-foreground">
+            Numéro de commande <strong className="text-foreground">{order.orderNumber}</strong>
+          </p>
+          <p className="text-lg font-semibold">
+            {formatMoney({ amount: Math.round(order.total * 1000), currency: "TND" })}
+          </p>
+          <div className="flex justify-center gap-3 pt-2">
+            <Button asChild>
+              <Link to="/account/orders">Voir mes commandes</Link>
+            </Button>
+            <Button asChild variant="outline">
+              <Link to="/catalogue">Continuer mes achats</Link>
+            </Button>
+          </div>
+        </div>
+      </SiteLayout>
+    );
+  }
+
+  if (cart.lines.length === 0) {
+    return (
+      <SiteLayout>
+        <div className="container-page flex flex-col items-center gap-4 py-24 text-center">
+          <p className="text-lg font-medium">Ton panier est vide.</p>
+          <Button asChild size="lg">
+            <Link to="/catalogue">Voir le catalogue</Link>
+          </Button>
+        </div>
+      </SiteLayout>
+    );
+  }
+
+  const shippingCost = { amount: CHECKOUT_SHIPPING_COST_MINOR, currency: "TND" as const };
+  const total = cart.subtotal + shippingCost.amount;
+  const canSubmit =
+    address.recipientName.trim() !== "" &&
+    address.phone.trim() !== "" &&
+    address.addressLine1.trim() !== "" &&
+    address.city.trim() !== "" &&
+    address.governorate.trim() !== "" &&
+    !placeOrder.isPending;
 
-function Row({ label, value }: { label: string; value: string }) {
   return (
-    <div className="flex justify-between">
-      <dt className="text-muted-foreground">{label}</dt>
-      <dd className="font-medium">{value}</dd>
-    </div>
+    <SiteLayout>
+      <form
+        className="container-page grid gap-8 py-10 lg:grid-cols-[1fr_360px]"
+        onSubmit={(e) => {
+          e.preventDefault();
+          if (canSubmit) placeOrder.mutate();
+        }}
+      >
+        <div className="space-y-6">
+          <Card className="space-y-4 p-6">
+            <div className="flex items-center gap-2 font-semibold">
+              <MapPin className="h-4 w-4" /> Adresse de livraison
+            </div>
+            <div className="grid gap-4 sm:grid-cols-2">
+              <div className="space-y-1.5">
+                <Label htmlFor="recipientName">Nom du destinataire</Label>
+                <Input
+                  id="recipientName"
+                  value={address.recipientName}
+                  onChange={field("recipientName")}
+                  required
+                />
+              </div>
+              <div className="space-y-1.5">
+                <Label htmlFor="phone">Téléphone</Label>
+                <Input id="phone" value={address.phone} onChange={field("phone")} required />
+              </div>
+            </div>
+            <div className="space-y-1.5">
+              <Label htmlFor="addressLine1">Adresse</Label>
+              <Input
+                id="addressLine1"
+                value={address.addressLine1}
+                onChange={field("addressLine1")}
+                required
+              />
+            </div>
+            <div className="space-y-1.5">
+              <Label htmlFor="addressLine2">Complément (optionnel)</Label>
+              <Input
+                id="addressLine2"
+                value={address.addressLine2}
+                onChange={field("addressLine2")}
+              />
+            </div>
+            <div className="grid gap-4 sm:grid-cols-3">
+              <div className="space-y-1.5">
+                <Label htmlFor="city">Ville</Label>
+                <Input id="city" value={address.city} onChange={field("city")} required />
+              </div>
+              <div className="space-y-1.5">
+                <Label htmlFor="governorate">Gouvernorat</Label>
+                <Input
+                  id="governorate"
+                  value={address.governorate}
+                  onChange={field("governorate")}
+                  required
+                />
+              </div>
+              <div className="space-y-1.5">
+                <Label htmlFor="postalCode">Code postal</Label>
+                <Input id="postalCode" value={address.postalCode} onChange={field("postalCode")} />
+              </div>
+            </div>
+          </Card>
+
+          <Card className="space-y-4 p-6">
+            <div className="flex items-center gap-2 font-semibold">
+              <CreditCard className="h-4 w-4" /> Mode de paiement
+            </div>
+            <RadioGroup
+              value={paymentMethod}
+              onValueChange={(v) => setPaymentMethod(v as PaymentMethod)}
+            >
+              {PAYMENT_OPTIONS.map((opt) => (
+                <label
+                  key={opt.value}
+                  className="flex cursor-pointer items-start gap-3 rounded-lg border p-3 has-[[data-state=checked]]:border-primary"
+                >
+                  <RadioGroupItem value={opt.value} className="mt-1" />
+                  <div>
+                    <p className="font-medium">{opt.label}</p>
+                    <p className="text-sm text-muted-foreground">{opt.hint}</p>
+                  </div>
+                </label>
+              ))}
+            </RadioGroup>
+          </Card>
+
+          {placeOrder.isError && (
+            <Alert variant="destructive">
+              <AlertDescription>
+                {placeOrder.error instanceof Error
+                  ? placeOrder.error.message
+                  : "Une erreur est survenue, réessaie."}
+              </AlertDescription>
+            </Alert>
+          )}
+        </div>
+
+        <Card className="h-fit space-y-4 p-6">
+          <h2 className="font-semibold">Récapitulatif</h2>
+          <div className="space-y-2">
+            {cart.lines.map((line) => (
+              <div key={line.id} className="flex justify-between text-sm">
+                <span className="text-muted-foreground">
+                  {line.product.name} × {line.quantity}
+                </span>
+                <span>{formatMoney(line.lineTotal)}</span>
+              </div>
+            ))}
+          </div>
+          <Separator />
+          <Row
+            label={`Articles (${cart.count})`}
+            value={formatMoney({ amount: cart.subtotal, currency: "TND" })}
+          />
+          <Row label="Livraison" value={formatMoney(shippingCost)} />
+          <Separator />
+          <Row label="Total" value={formatMoney({ amount: total, currency: "TND" })} bold />
+          <Button type="submit" className="w-full" size="lg" disabled={!canSubmit}>
+            {placeOrder.isPending ? "Création de la commande…" : "Confirmer la commande"}
+          </Button>
+          <p className="flex items-center gap-1 text-xs text-muted-foreground">
+            <ShieldCheck className="h-3 w-3" /> Paiement sécurisé — données chiffrées
+          </p>
+        </Card>
+      </form>
+    </SiteLayout>
   );
 }
