/**
 * Helpers serveur de création de commande.
 * Utilise EXCLUSIVEMENT le client Supabase authentifié (RLS as user).
 * Aucun client service-role ici — même contrainte que cart.server.ts.
 *
 * Autorité des prix/totaux : les triggers DB existants (enforce_order_item_price,
 * enforce_order_totals, recompute_order_totals, resolve_product_price) recalculent
 * unit_price/line_total/subtotal/total à l'insertion. Ce fichier ne fait JAMAIS
 * confiance à un prix qu'il aurait lui-même calculé — il lit toujours la valeur
 * finale en DB après coup (voir `placeOrder`, étape 6).
 */
import type { AuthedClient } from "./cart.server";
import { readCart } from "./cart.server";

export const PAYMENT_METHODS = ["card", "bank_transfer", "cash_on_delivery"] as const;
export type PaymentMethod = (typeof PAYMENT_METHODS)[number];

/**
 * Frais de port MVP — PROVISOIRE, non validé comme politique commerciale.
 * Unité mineure (millimes), cohérent avec `toMoney()`/`Money.amount` utilisé
 * partout ailleurs dans l'app. 8000 = 8.000 DT. Source UNIQUE : ne jamais
 * dupliquer cette valeur ailleurs. À remplacer avant tout lancement réel par
 * une vraie politique de frais de port (fixe, par gouvernorat, par poids...).
 *
 * GAP CONNU (autorité) : cette constante n'est appliquée que par ce chemin
 * applicatif (Server Function). `shipping_cost` n'est PAS verrouillé côté
 * DB — un appel REST/PostgREST direct authentifié pourrait insérer une
 * valeur arbitraire dans `orders.shipping_cost` (aucun trigger ne la
 * contraint, contrairement à `subtotal`/`total`/`unit_price`). Protégé
 * uniquement pour le parcours officiel de l'application. Remédiation DB
 * (contrainte CHECK ou verrouillage trigger) : décision PO, hors périmètre
 * de ce fichier.
 */
export const CHECKOUT_SHIPPING_COST_MINOR = 8000;

export type AddressInput = {
  recipientName: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  governorate: string;
  postalCode?: string;
};

export function normalizeAddressInput(input: unknown): AddressInput {
  const v = (input ?? {}) as Record<string, unknown>;
  const str = (x: unknown) => String(x ?? "").trim();

  const recipientName = str(v.recipientName);
  const phone = str(v.phone);
  const addressLine1 = str(v.addressLine1);
  const city = str(v.city);
  const governorate = str(v.governorate);

  if (!recipientName) throw new Error("Nom du destinataire requis");
  if (!phone) throw new Error("Téléphone requis");
  if (!addressLine1) throw new Error("Adresse requise");
  if (!city) throw new Error("Ville requise");
  if (!governorate) throw new Error("Gouvernorat requis");

  return {
    recipientName,
    phone,
    addressLine1,
    addressLine2: v.addressLine2 ? str(v.addressLine2) : undefined,
    city,
    governorate,
    postalCode: v.postalCode ? str(v.postalCode) : undefined,
  };
}

export function normalizePaymentMethod(input: unknown): PaymentMethod {
  const v = String(input ?? "");
  if (!(PAYMENT_METHODS as readonly string[]).includes(v)) {
    throw new Error("Mode de paiement invalide");
  }
  return v as PaymentMethod;
}

/**
 * BAMS-{année}-{6 chiffres}. Pas de séquence DB (aucune n'existe) — unicité
 * gérée par retry sur violation de contrainte UNIQUE (voir placeOrder).
 */
function generateOrderNumber(): string {
  const year = new Date().getFullYear();
  const rand = Math.floor(100000 + Math.random() * 900000);
  return `BAMS-${year}-${rand}`;
}

export type PlaceOrderResult = {
  orderId: string;
  orderNumber: string;
  status: string;
  subtotal: number;
  shippingCost: number;
  total: number;
};

/**
 * REAL CART → SERVER VALIDATION → CREATE ADDRESS → CREATE ORDER →
 * CREATE ORDER_ITEMS SNAPSHOTS → CLEAR CART → RETURN REAL ORDER.
 *
 * Atomicité : PAS de transaction DB multi-étapes (aucune RPC n'existe pour
 * ça — en créer une sortirait du scope de cette tâche, voir le rapport).
 * Ce qui EST garanti :
 *   - l'insert de tous les order_items est UNE seule instruction SQL
 *     multi-lignes → atomique au niveau Postgres (tout ou rien) ;
 *   - subtotal/total ne sont JAMAIS calculés ici : toujours relus depuis la
 *     DB après le trigger `recompute_order_totals`.
 *
 * GAP CONNU (commande fantôme) : si l'insert order_items échoue APRÈS que
 * `orders` a été créée, AUCUNE compensation n'est possible — `authenticated`
 * n'a ni GRANT DELETE ni policy UPDATE non-staff sur `orders` (vérifié :
 * seule `orders_staff_update` existe, réservée à `is_staff()`). Une
 * tentative de DELETE échouerait silencieusement, c'est pourquoi elle n'est
 * plus tentée ici (voir plus bas). Une commande à 0 ligne peut donc rester
 * en base dans ce cas rare — `status=pending_payment`, aucun `order_items`.
 * Remédiation cible : RPC transactionnelle `create_order`. Décision PO
 * requise, non implémentée ici.
 *
 * GAP CONNU (quantité) : la commande hérite de la quantité déjà validée par
 * le panier (`cart_items`). La DB n'impose actuellement aucune borne
 * (ex. 1–99) au niveau `order_items.quantity` — seule une valeur positive
 * est vérifiée par le trigger. Pas de correction ici (toucherait
 * cart.server.ts/schema, hors périmètre de ce fichier).
 *
 * GAP CONNU (idempotence) : le double-clic est bloqué côté UI
 * (`checkout.tsx`, bouton désactivé pendant la mutation). Deux onglets ou
 * deux requêtes réseau parallèles peuvent en revanche produire deux
 * commandes distinctes — aucune protection DB (idempotency key) n'existe.
 * Décision PO requise pour une vraie garantie.
 */
export async function placeOrder(
  supabase: AuthedClient,
  userId: string,
  address: AddressInput,
  paymentMethod: PaymentMethod,
): Promise<PlaceOrderResult> {
  const cart = await readCart(supabase, userId);
  if (cart.lines.length === 0) {
    throw new Error("Le panier est vide");
  }

  const unavailable = cart.lines.find((l) => !l.product.active);
  if (unavailable) {
    throw new Error(`"${unavailable.product.name}" n'est plus disponible à la vente`);
  }
  // GAP CONNU (Retail Activation Gate) : cette vérification ne couvre que
  // `products.active`. La colonne `catalog_activation_status` (DRAFT /
  // BLOCKED / ACTIVE) existe en DB mais n'est vérifiée ni ici, ni par les
  // policies RLS `products_public_read_active`/`products_auth_read`
  // (toutes deux `USING (active)` uniquement — vérifié dans les
  // migrations). Un produit `active=true` mais pas encore
  // `catalog_activation_status='ACTIVE'` resterait commandable. Correction
  // hors périmètre de ce fichier (toucherait catalog.functions.ts /
  // cart.server.ts / RLS) — décision PO requise.

  // Coupon éventuellement appliqué au panier. Lecture directe (pas via
  // cart.server.ts, hors périmètre) — même RLS `carts_self` que readCart().
  // Aucune revalidation ici : la remise reste calculée par la DB
  // (`recompute_order_totals`), on ne fait que transmettre le code.
  let couponCode: string | null = null;
  if (cart.cartId) {
    const { data: cartRow } = await supabase
      .from("carts")
      .select("applied_coupon_code")
      .eq("id", cart.cartId)
      .maybeSingle();
    couponCode = cartRow?.applied_coupon_code ?? null;
  }

  const { data: addressRow, error: addressError } = await supabase
    .from("addresses")
    .insert({
      user_id: userId,
      recipient_name: address.recipientName,
      phone: address.phone,
      address_line1: address.addressLine1,
      address_line2: address.addressLine2 ?? null,
      city: address.city,
      governorate: address.governorate,
      postal_code: address.postalCode ?? null,
      is_default: false,
    })
    .select("id")
    .single();
  if (addressError || !addressRow) {
    throw new Error(addressError?.message ?? "Échec de création de l'adresse");
  }

  const shippingCostTnd = CHECKOUT_SHIPPING_COST_MINOR / 1000;
  let orderId: string | null = null;

  for (let attempt = 0; attempt < 3 && !orderId; attempt++) {
    const { data: orderRow, error: orderError } = await supabase
      .from("orders")
      .insert({
        order_number: generateOrderNumber(),
        user_id: userId,
        shipping_address_id: addressRow.id,
        payment_method: paymentMethod,
        shipping_cost: shippingCostTnd,
        coupon_code: couponCode,
        // Valeurs bouchon : le trigger `enforce_order_totals` impose 0 pour
        // un non-staff de toute façon ; `recompute_order_totals` les
        // remplacera par les vraies valeurs (et appliquera la remise du
        // coupon éventuel) après l'insert des lignes.
        subtotal: 0,
        discount_total: 0,
        total: 0,
      })
      .select("id")
      .single();

    if (!orderError && orderRow) {
      orderId = orderRow.id;
      break;
    }
    // 23505 = unique_violation → collision order_number, on réessaie.
    if (orderError && orderError.code !== "23505") {
      throw new Error(orderError.message);
    }
  }
  if (!orderId) {
    throw new Error("Impossible de générer un numéro de commande unique — réessaie");
  }

  const { error: itemsError } = await supabase.from("order_items").insert(
    cart.lines.map((line) => ({
      order_id: orderId as string,
      product_id: line.productId,
      product_name: line.product.name,
      quantity: line.quantity,
      // Ignorés par le trigger enforce_order_item_price (autorité DB réelle).
      unit_price: 0,
      line_total: 0,
    })),
  );

  if (itemsError) {
    // Pas de compensation possible ici : `authenticated` n'a ni GRANT DELETE
    // ni policy UPDATE sur `orders` (orders_staff_update est réservée au
    // staff — vérifié dans la migration). Une tentative de DELETE échouerait
    // silencieusement. On assume donc, honnêtement, qu'une commande à 0
    // ligne peut rester en base dans ce cas rare (statut pending_payment,
    // total = shipping_cost). Nettoyage : admin uniquement, ou une future
    // policy dédiée — décision PO, pas une correction silencieuse ici.
    throw new Error(itemsError.message);
  }

  const { data: finalOrder, error: finalError } = await supabase
    .from("orders")
    .select("id, order_number, status, subtotal, shipping_cost, total")
    .eq("id", orderId)
    .single();
  if (finalError || !finalOrder) {
    throw new Error(finalError?.message ?? "Commande créée mais impossible à relire");
  }

  if (cart.cartId) {
    const { error: clearError } = await supabase
      .from("cart_items")
      .delete()
      .eq("cart_id", cart.cartId);
    if (clearError) throw new Error(clearError.message);
  }

  return {
    orderId: finalOrder.id,
    orderNumber: finalOrder.order_number,
    status: finalOrder.status,
    subtotal: Number(finalOrder.subtotal),
    shippingCost: Number(finalOrder.shipping_cost),
    total: Number(finalOrder.total),
  };
}
